#! /bin/bash
#picom
lxpolkit &
pipewire &
pipewire-pulse &
tint2 &
/home/$USER/.fehbg 
#tint2 -c .config/tint2/unleashed/unleashed-clock.tint2rc 
nm-applet &